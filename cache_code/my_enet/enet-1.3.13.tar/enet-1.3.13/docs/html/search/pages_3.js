var searchData=
[
  ['installation',['Installation',['../Installation.html',1,'']]],
  ['irc_20channel',['IRC Channel',['../IRCChannel.html',1,'']]]
];
